sap.ui.define([
	"customUI/test/unit/controller/MyStartUI.controller"
], function () {
	"use strict";
});
