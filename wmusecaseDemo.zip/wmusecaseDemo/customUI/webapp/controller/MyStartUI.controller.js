sap.ui.define(["sap/ui/core/mvc/Controller"],
/**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller) {
    "use strict";

    return Controller.extend("customUI.controller.MyStartUI", {
        onInit: function () {
            var oContextModel = this.getView().getModel("context");
            var oHeaderData = oContextModel.getData().headerData;
            var oConfidenceData = oContextModel.getData().headerConfidence;
            var sPdf = oContextModel.getData().attachment ? oContextModel.getData().attachment.body : '';
           
            const pdfData = "data:application/pdf;base64," + sPdf;
            var pdf = this.getView().byId("pdfViewer");
            pdf.setContent('<embed type="application/pdf" height="600px" width="100%" src="' + pdfData + '" />')

        
        },
        onAttachmentPress: function () {
            var sSource = "data:application/pdf;base64," + this.getView().getModel("context").getData().attachment.body;
            var oLink = this.getView().byId("link");
            oLink.setHref(sSource);
            let domLink = oLink.getDomRef();
            domLink.download = this.getView().getModel("context").getData().filename;
            domLink.dispatchEvent(new MouseEvent('click'));
        },
        startWorkflowInstance: function () {
            var model = this.getView().getModel();
            var definitionId = "workflowApp";
            var initialContext = model.getProperty("/initialContext");

            var data = {
                definitionId: definitionId,
                context: JSON.parse(initialContext)
            };

            $.ajax({
                url: this._getWorkflowRuntimeBaseURL() + "/workflow-instances",
                method: "POST",
                async: false,
                contentType: "application/json",
                headers: {
                    "X-CSRF-Token": this._fetchToken()
                },
                data: JSON.stringify(data),
                success: function (result, xhr, data) {
                    model.setProperty("/apiResponse", JSON.stringify(result, null, 4));
                },
                error: function (request, status, error) {
                    var response = JSON.parse(request.responseText);
                    model.setProperty("/apiResponse", JSON.stringify(response, null, 4));
                }
            });
        },

        _fetchToken: function () {
            var fetchedToken;

            jQuery.ajax({
                url: this._getWorkflowRuntimeBaseURL() + "/xsrf-token",
                method: "GET",
                async: false,
                headers: {
                    "X-CSRF-Token": "Fetch"
                },
                success(result, xhr, data) {
                    fetchedToken = data.getResponseHeader("X-CSRF-Token");
                }
            });
            return fetchedToken;
        },

        _getWorkflowRuntimeBaseURL: function () {
            var appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            var appPath = appId.replaceAll(".", "/");
            var appModulePath = jQuery.sap.getModulePath(appPath);

            return appModulePath + "/bpmworkflowruntime/v1";
        },
        confidenceRow: function(row,confData){
            return "(Confidence: "+ confData[this.getView().getModel("context").getData().headerData.to_SupplierInvoiceItemGLAcct.results.indexOf(row)].SupplierInvoiceItemAmount + "%)";
        }
    });
});
