var decision = {
	"UserId": $.usertasks.usertask5.last.processor,
	"Role": "Local Manager",
	"Action": $.usertasks.usertask5.last.decision,
	"Comment": $.context.comment
};

$.context.History.push(decision);
$.context.comment = "";

$.context.decision = $.usertasks.usertask5.last.decision;
