var decision = {
	"UserId": $.usertasks.usertask7.last.processor,
	"Role": "Central Manager",
	"Action": $.usertasks.usertask7.last.decision,
	"Comment": $.context.comment
};

$.context.History.push(decision);
$.context.comment = "";

$.context.decision = $.usertasks.usertask7.last.decision;
